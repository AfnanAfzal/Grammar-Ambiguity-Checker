"""
Utility module — styling constants, fonts, and helper functions.
"""
import tkinter as tk
from tkinter import messagebox

# Modern Dark Professional Color Palette
COLORS = {
    'bg': '#0b1120',
    'card': '#151e32',
    'card_hover': '#1a2540',
    'input': '#1e293b',
    'input_border': '#334155',
    'accent': '#38bdf8',
    'accent_hover': '#7dd3fc',
    'accent_dark': '#0284c7',
    'success': '#22c55e',
    'success_bg': '#064e3b',
    'danger': '#ef4444',
    'danger_bg': '#7f1d1d',
    'warning': '#f59e0b',
    'warning_bg': '#78350f',
    'fg': '#f8fafc',
    'fg_muted': '#94a3b8',
    'border': '#2d3a4f',
    'insert': '#f8fafc',
}

FONTS = {
    'title': ('Segoe UI', 28, 'bold'),
    'subtitle': ('Segoe UI', 13, 'normal'),
    'heading': ('Segoe UI', 12, 'bold'),
    'body': ('Segoe UI', 11, 'normal'),
    'mono': ('Cascadia Code', 11, 'normal'),
    'mono_bold': ('Cascadia Code', 11, 'bold'),
    'button': ('Segoe UI', 10, 'bold'),
    'status': ('Segoe UI', 10, 'normal'),
    'big': ('Segoe UI', 32, 'bold'),
    'medium': ('Segoe UI', 18, 'bold'),
}


def show_error(parent, title, message):
    messagebox.showerror(title, message, parent=parent)


def show_info(parent, title, message):
    messagebox.showinfo(title, message, parent=parent)
